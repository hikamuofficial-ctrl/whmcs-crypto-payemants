<?php

require_once __DIR__ . '/init.php';

CoinGate\Client::setAppInfo('WHMCS Extension', '2.0.0');
