<?php

namespace CoinGate\Resources;

/**
 * Related guide: <a href="https://developer.coingate.com/docs/create-order">Create Order</a>.
 *
 * @property string $token
 */
class CreateOrder extends Order
{
}
