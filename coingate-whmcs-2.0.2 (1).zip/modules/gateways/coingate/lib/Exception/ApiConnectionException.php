<?php

namespace CoinGate\Exception;

use Exception;

class ApiConnectionException extends Exception
{
}
